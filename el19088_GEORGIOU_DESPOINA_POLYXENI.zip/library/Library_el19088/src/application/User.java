package application;
import java.io.Serializable;

public class User  implements Serializable{
	
	private String username, passward, name, lastname, id, mail;
	 private int nobb; //numberOfBooksBorrowed;
	
	public User() {
		username=null;
		passward=null;
		name=null;
		lastname=null;
		id=null;
		mail=null;
		nobb=0;
		
}
	
	public User(String username, String passward, String name, String lastname, String id, String mail) {
		this.username=username;
		this.passward=passward;
		this.name=name;
		this.lastname=lastname;
		this.id=id;
		this.mail=mail;
	}
	
	public String getID() {
        return id;
    }
	
	public String getPassword() {
        return passward; 
    }
	public String getEmail() {
        return mail; 
    }

    public String getUsername() {
        return username; 
    }
	public void setUsername(String username) {
        this.username = username;
    }

    public void setPassward(String passward) {
        this.passward = passward;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public void setID(String id) {
        this.id = id;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }
    
    public void setNumberOfBooksBorrowed(int nobb) {
        this.nobb = nobb;
    }
	
    public int getNumberOfBooksBorrowed() {
        return nobb;
    }
    
    public boolean canBorrowMoreBooks() {
        return nobb < 2;
    }

 
	
	@Override
	public String toString() {
		return "\nUsername: " + username + "\nPassward: " + passward + "\nName: " + name + "\nLastname: " + lastname +
				"\nID: " + id + "\nMail: " + mail + "\nNumber of Books Borrowed: " + nobb + "\n";
	}
	
	
	public boolean equals(Object obj) {
	    if (this == obj) {
	        return true;
	    }
	    if (obj == null || getClass() != obj.getClass()) {
	        return false;
	    }
	    User other = (User) obj;
	    return id.equals(other.id);
	}
	
}