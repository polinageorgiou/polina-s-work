package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.fxml.Initializable;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.fxml.FXMLLoader;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class Scene4Controller implements Initializable {

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}
	
	@FXML
	private void switchToAddBook(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AddBook.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    	
    }
	
	 
	@FXML
	private void switchToUpdateBook(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("UpdateBook.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    	
    }

	@FXML
	private void switchToDeleteBook(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("DeleteBook.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    	
    }
	
	@FXML
	private void switchToListBooks(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("ListBooks.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    	
    }
	
	
	
	@FXML
	private void switchToAddCategory(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AddCategory.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    	
    }
	
	 
	@FXML
	private void switchToUpdateCategory(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("UpdateCategory.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    	
    }

	@FXML
	private void switchToDeleteCategory(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("DeleteCategory.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    	
    }
	
	@FXML
	private void switchToListCategories(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("ListCategories.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    	
    }
	
	
	
	@FXML
	private void switchToAddUser(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AddUser.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    	
    }
	
	 
	@FXML
	private void switchToUpdateUser(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("UpdateUser.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    	
    }

	@FXML
	private void switchToDeleteUser(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("DeleteUser.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    	
    }
	
	@FXML
	private void switchToListUsers(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("ListUsers.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    	
    }
	
	
	@FXML
	private void switchToAddLoan(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AddLoan.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    	
    }
	
	 
	@FXML
	private void switchToTerminateLoan(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("TerminateLoan.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    	
    }

	@FXML
	private void switchToListLoans(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("ListLoans.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    	
    }
	
	
	
	 @FXML
	    private void switchToScene1(ActionEvent event) {
	  	  
	  	        
	  	        ((Stage)((Node) event.getSource()).getScene().getWindow()).close();
	  	        
	  	    
	  	}
	 
	 


}
