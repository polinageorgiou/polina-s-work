package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.fxml.Initializable;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.fxml.FXMLLoader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Comparator;
import java.util.stream.Collectors;

import application.Book.CommentAndRating;

public class Scene1Controller implements Initializable {
	
	//private List<CommentAndRating> commentsAndRatings;
	


    @FXML
    private TextField Username;
    @FXML
    private PasswordField Passward;
    @FXML
    private TextField Username1;
    @FXML
    private TextField Passward1;
    @FXML
    private TextField FirstName;
    @FXML
    private TextField LastName;
    @FXML
    private TextField ID;
    @FXML
    private TextField Email;
    @FXML
    private TextArea outputTextArea;

    
    
    
    static String enterUsername;
	static String enterPassward;
	String UsernameA;
	String PasswardA;
	String FirstNameA;
	String LastNameA;
	String IDA;
	String EmailA;

   

  

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Εδώ μπορείτε να προσθέσετε οποιαδήποτε αρχικοποίηση χρειάζεται
    }
    
    
    private void showMessage(String message) {
        outputTextArea.appendText(message + "\n");
    }

    
    
    public User login(String username, String password) {
        for (User currentUser : UserManager.getUserManager().users) {
            if (currentUser.getUsername().equals(username) && currentUser.getPassword().equals(password)) {
                return currentUser;
            }
        }
        return null;
    }
    
    
    
    
    public void loginn() {
        enterUsername = Username.getText();
        enterPassward = Passward.getText();

        User loggedInUser = login(enterUsername, enterPassward);

        if (loggedInUser != null) {
        	outputTextArea.clear();
        	showMessage("Login successful.");

            if (loggedInUser.getUsername().equals("medialab") && loggedInUser.getPassword().equals("medialab_2024")) {
            	outputTextArea.clear();
            	showMessage("Logged in as administrator.");
                UserManager.getUserManager().admin = true;
                switchToScene4();
            } else {
            	outputTextArea.clear();
            	showMessage("Logged in as regular user.");
                UserManager.getUserManager().noadmin = true;
                switchToScene3();
               
            }
        } else {
        	outputTextArea.clear();
        	showMessage("Login failed. Incorrect username or password.");
        }
    }
    
    
    public void showbooks() {
        
        List<Book> collection=Library.getLibrary().getBooks();


    	if (!collection.isEmpty()) {
    		outputTextArea.clear();
    		showMessage("Books found:");
    	    for (Book book : collection) {
    	    	showMessage(book.toString());
    	        for (Book.CommentAndRating commentAndRating : book.getCommentsAndRatings()) {
    	        	showMessage("--------");
    	        	showMessage("User: " + commentAndRating.getUser());
    	        	showMessage("Comment: " + commentAndRating.getComment());
    	        	showMessage("Rating: " + commentAndRating.getRating());
    	        }
    	    
    	        
    	    }
    	} else {
    		outputTextArea.clear();
    		showMessage("No books found.");
    	}
    	
        }
    
    
    
    
    
    
    



   
    
    @FXML
    private void switchToScene3() {
  	    try {
  	        Parent root = FXMLLoader.load(getClass().getResource("Scene3.fxml"));
  	        Stage stage = new Stage();
  	        Scene scene = new Scene(root);
  	        stage.setScene(scene);
  	        stage.show();
  	    } catch (IOException e) {
  	        e.printStackTrace();
  	        
  	    }
  	}
    
    @FXML
    private void switchToScene4() {
  	    try {
  	        Parent root = FXMLLoader.load(getClass().getResource("Scene4.fxml"));
  	        Stage stage = new Stage();
  	        Scene scene = new Scene(root);
  	        stage.setScene(scene);
  	        stage.show();
  	    } catch (IOException e) {
  	        e.printStackTrace();
  	        
  	    }
  	}
    
    

    
    @FXML
    private void switchToScene2(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Scene2.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    	
    }
    
   
    
    
   
    
    
   

    
    }

