package application;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SearchController implements Initializable{
	
	
	@FXML
    private TextField Title;
    @FXML
    private TextField Author;
    @FXML
    private TextField Year;
    @FXML
    private TextArea outputTextArea;

    
    private void showMessage(String message) {
        outputTextArea.appendText(message + "\n");
    }
    
    String title;
	String author;
	int year;
    
    public void search() {
    title=Title.getText();
    author=Author.getText();
    year = Integer.parseInt(Year.getText());

	List<Book> searchResult = Library.getLibrary().searchBook(title, author, year);

	if (!searchResult.isEmpty()) {
		showMessage("Books found:");
	    for (Book book : searchResult) {
	    	showMessage(book.toString());
	        for (Book.CommentAndRating commentAndRating : book.getCommentsAndRatings()) {
	        	showMessage("Comment: " + commentAndRating.getComment());
	        	showMessage("Rating: " + commentAndRating.getRating());
	        }
	    
	        //System.out.println(book.getCommentsAndRatings());
	    }
	} else {
		showMessage("No books found.");
	}
	
    }
    
    
    
    @FXML
    private void switchToScene3(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Scene3.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    	
    }
    
    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

}
