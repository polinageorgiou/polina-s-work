package application;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class CategoryManager implements Serializable{
	
	private static CategoryManager instance;
	
    private List<Category> categories;

  public static  CategoryManager getCategoryManager() {
	if (instance==null) {
		FileInputStream fis = null;
		ObjectInputStream in = null;
		
		File file = new File("saveCategory.ser");
		
		try {
			fis = new FileInputStream(file);
			in = new ObjectInputStream(fis);
			instance = (CategoryManager) in.readObject();

			fis.close();
			in.close();
			
		} catch (IOException e) {
			instance=new CategoryManager();
			instance.categories = new ArrayList<>();
			return instance;
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
		
	
		
	}
	return instance;
}
  
	public static void save() {	
		LoadController.save(instance, "medialab/saveCategory.ser");
	}
	


    public List<Category> getCategories() {
        return categories;
    }

    public void addCategory(Category category) {
        categories.add(category);
    }

    public void removeCategory(Category category) {
        Iterator<Category> iterator = categories.iterator();
        while (iterator.hasNext()) {
            Category currentCategory = iterator.next();
            if (currentCategory.equals(category)) {
                iterator.remove();
                break;
            }
        }
    }

    public void updateCategory(Category category, String newTitle) {
        category.setTitle(newTitle);
    }

    

    
}
