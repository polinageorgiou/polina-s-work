package application;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;

public class Loan implements Serializable {

    private User user;
    private Book book;
    private LocalDate startDate;
    private int loanDurationInDays = 5;
 

    public Loan(Book book, User user) {
        this.user = user;
        this.book = book;
        this.startDate = LocalDate.now();
    }

    public User getUser() {
        return user;
    }

    public Book getBook() {
        return book;
    }
    
    public LocalDate getStartDate() {
        return startDate;
    }
    
    public LocalDate getDueDate() {
        return startDate.plusDays(loanDurationInDays);
    }

    
    
    @Override
	public String toString() {
		return "\nUser: " + user + "\nBook " + book + "\n";
	}
}
