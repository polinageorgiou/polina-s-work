package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.fxml.Initializable;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.fxml.FXMLLoader;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class Scene2Controller implements Initializable {

	

    @FXML
    private TextField Username;
    @FXML
    private TextField Passward;
    @FXML
    private TextField Username1;
    @FXML
    private TextField Passward1;
    @FXML
    private TextField FirstName;
    @FXML
    private TextField LastName;
    @FXML
    private TextField ID;
    @FXML
    private TextField Email;
    @FXML
    private TextArea outputTextArea;
    
    
    String enterUsername;
	String enterPassward;
	String UsernameA;
	String PasswardA;
	String FirstNameA;
	String LastNameA;
	String IDA;
	String EmailA;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		
	}
	
	  private void showMessage(String message) {
	        outputTextArea.appendText(message + "\n");
	    }
	
	
	  public void registerUser() {
		    UsernameA = Username1.getText();
		    PasswardA = Passward1.getText();
		    FirstNameA = FirstName.getText();
		    LastNameA = LastName.getText();
		    IDA = ID.getText();   
		    EmailA = Email.getText(); 

		    List<User> users = UserManager.getUserManager().getUsers();
		    boolean userExists = false;
		    for (User user : users) {
		        if (user.getID().equals(IDA) || user.getEmail().equals(EmailA)) {
		            userExists = true;
		            break;
		        }
		    } 
		    if (userExists) {
		    	outputTextArea.clear();
		        showMessage("Registration not successful, user with the same ID or email already exists.");
		    } else {
		        User newUser = new User(UsernameA, PasswardA, FirstNameA, LastNameA, IDA, EmailA);
		        UserManager.getUserManager().addUser(newUser);
		        outputTextArea.clear();
		        showMessage("Registration successful.");
		    }
		}

	 
	
	 
	 @FXML
	    private void switchToScene1(ActionEvent event) throws IOException {
	        Parent root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
	        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
	        Scene scene = new Scene(root);
	        stage.setScene(scene);
	        stage.show();
	    	
	    }
	 
	 

}
