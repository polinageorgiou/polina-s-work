package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class BookOperationsController {
	@FXML
    private TextField OldISBN;
	@FXML
    private TextField Title;
    @FXML
    private TextField Author;
    @FXML
    private TextField Publisher;
    @FXML
    private TextField Category;
    @FXML
    private TextField ISBN;
    @FXML
    private TextField YOP;
    @FXML
    private TextField NOC;
    @FXML
    private TextArea outputTextArea;
    
    private void showMessage(String message) {
        outputTextArea.appendText(message + "\n");
    }
    
    
    
    public  void addBook(){
		String title=Title.getText();
		String author=Author.getText();
		String publisher=Publisher.getText();
		String category=Category.getText();
		int isbn=Integer.parseInt(ISBN.getText());
		int yop=Integer.parseInt(YOP.getText());
		int noc=Integer.parseInt(NOC.getText());
		 
		
		
		Book b = new Book(title, author, publisher, category, isbn, yop, noc);
		Library.getLibrary().addBook(b);
		showMessage("Book added successsfully");
	}
    
    
    public void updateBook() {
        int isbnToUpdate = Integer.parseInt(OldISBN.getText());

        Book bookToUpdate = findBookByISBN(isbnToUpdate);

        if (bookToUpdate != null) {
            updateBookInformation(bookToUpdate);
            showMessage("Book details updated successfully.");
        } else {
        	showMessage("Book not found.");
        }
    }
	
	
	private static Book findBookByISBN(int isbn) {
	    for (Book book : Library.getLibrary().getBooks()) {
	        if (book.getIsbn() == isbn) {
	            return book;
	        }
	    }
	    return null; 
	}

	private  void updateBookInformation(Book book) {
	    

	    String newTitle = Title.getText();
	    book.setTitle(newTitle);

	    String newAuthor = Author.getText();
	    book.setAuthor(newAuthor);

	    String newPublisher = Publisher.getText();
	    book.setPublisher(newPublisher);

	    String newCategory = Category.getText();
        book.setCategory(newCategory);

        int newIsbn = Integer.parseInt(ISBN.getText());
	    book.setIsbn(newIsbn);


	    int newYop = Integer.parseInt(YOP.getText());
	    book.setYearOfPublishing(newYop);

	    int newNoc = Integer.parseInt(NOC.getText());
	    book.setNumberOfCopies(newNoc);

	}
	
	public void deleteBook() {
	    int isbnToDelete = Integer.parseInt(ISBN.getText());
	    Book bookToDelete = null;
	    for (Book book : Library.getLibrary().getBooks()) {
	        if (book.getIsbn() == isbnToDelete) {
	            bookToDelete = book;
	            break;
	        }
	    }

	    if (bookToDelete != null) {
	    	Library.getLibrary().removeBook(bookToDelete);
	    	LoanManager.getLoanManager().removeLoansForBook(bookToDelete);
	    	showMessage("Book deleted successfully.");
	    } else {
	    	showMessage("Book not found.");
	    }
	}
	
	public void listbooks() {
		
		showMessage(Library.getLibrary().toString());
	}
	
	@FXML
    private void switchToScene4(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Scene4.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    	
    }

}
