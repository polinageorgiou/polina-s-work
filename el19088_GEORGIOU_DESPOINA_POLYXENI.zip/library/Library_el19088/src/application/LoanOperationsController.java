package application;

import java.io.IOException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoanOperationsController {
	
	
	 @FXML
	    private TextField ID;
	 @FXML
	    private TextField ISBN;
	 @FXML
	    private TextArea outputTextArea;
	 
	 private List<Loan> loans;
	    
	    
	    private void showMessage(String message) {
	        outputTextArea.appendText(message + "\n");
	    }
	    
	    public void initialize() {
	        loans = new ArrayList<>();
	    }
	    
	    public  List<Loan> getLoans() {
	        return loans;
	    }

	
	
	public void addLoan() {
        String userId = ID.getText();
        User user = findUserByID(userId);

        int bookIsbn = Integer.parseInt(ISBN.getText());
        Book book = findBookByISBN(bookIsbn);

        if (user != null && book != null) {
        	LoanManager.getLoanManager().loanBook(book, user);
        	loanBook(book, user);
        } else {
        	showMessage("User or book not found.");
        }
    }
	
	

	
	
	
	public void loanBook(Book book, User user) {
        if (book.getNumberOfCopies() > 0 && user.canBorrowMoreBooks()) {
            book.setNumberOfCopies(book.getNumberOfCopies() - 1);
            user.setNumberOfBooksBorrowed(user.getNumberOfBooksBorrowed() + 1);
            showMessage("Book loan added successfully.");
        } else {
        	showMessage("No available copies of the book or user cannot borrow more books.");
        }
    }
	
	 public void addLoann(Loan loan) {
		 if (loans == null) {
	            loans = new ArrayList<>();
	        }
	        loans.add(loan);
	    }
	
	
	private static User findUserByID(String id) {
	    for (User user : UserManager.getUserManager().getUsers()) {
	        if (user.getID().equals(id)) {
	            return user;
	        }
	    }
	    return null;
	}
	
	private static Book findBookByISBN(int isbn) {
	    for (Book book : Library.getLibrary().getBooks()) {
	        if (book.getIsbn() == isbn) {
	            return book;
	        }
	    }
	    return null;
	}
	
	 public void returnBook() {
	        String userId = ID.getText();
	        User user = findUserByID(userId);

	        int bookIsbn = Integer.parseInt(ISBN.getText());
	        Book book = findBookByISBN(bookIsbn);

	        if (user != null && book != null) {
	            Loan loanToReturn = LoanManager.getLoanManager().findLoan(user, book);
	            if (loanToReturn != null) {
	            	terminateLoan(loanToReturn);
	            	showMessage("Book returned successfully.");
	            } else {
	            	showMessage("Loan not found.");
	            }
	        } else {
	        	showMessage("User or book not found.");
	        }
	    }
	 
	 public void terminateLoan(Loan loan) {
		 LoanManager.getLoanManager().removeLoan(loan);
	        checkLoanDueDate(loan);
	        //System.out.println("Loan terminated successfully.");
	    }
	 public void checkLoanDueDate(Loan loan) {
		 
	        LocalDate currentDate = LocalDate.now();
	        LocalDate dueDate = loan.getDueDate(); // Προσθέτουμε 5 ημέρες στην ημερομηνία έναρξης

	        long overdueDays = ChronoUnit.DAYS.between(dueDate, currentDate);

	        if (overdueDays > 0) {
	        	showMessage("This loan is overdue by " + overdueDays + " days.");
	           
	        }
	        else {
	        	showMessage("This loan is not overdue");
	        }
	    }
	 
	 public void listLoans() {
		    List<Loan> loans = LoanManager.getLoanManager().getLoans();
		    if (loans.isEmpty()) {
		    	showMessage("No loans available.");
		    } else {
		    	showMessage("List of loans:");
		        for (Loan currentloan : loans) {
		        	User currentUser = currentloan.getUser();
		        	String userName = currentUser.getUsername(); 
		        	showMessage("User:" + userName);
		        	//showMessage(currentloan.getUser());
		        	Book currentBook = currentloan.getBook();
		        	String bookName = currentBook.getTitle();
		        	showMessage("Book:" + bookName);
		        	//showMessage(currentloan.getBook());
		            //loan.checkLoanDueDate(currentloan);
		        	checkLoanDueDate(currentloan);
		        }
		    }
		}
	
	
	@FXML
	private void switchToScene4(ActionEvent event) throws IOException {
	    Parent root = FXMLLoader.load(getClass().getResource("Scene4.fxml"));
	    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
	    Scene scene = new Scene(root);
	    stage.setScene(scene);
	    stage.show();
		
	}
}
