package application;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class UserManager implements Serializable {
	
	private static UserManager instance;
	

	String enterUsername;
	String enterPassward;
	String UsernameA;
	String PasswardA;
	String FirstNameA;
	String LastNameA;
	String IDA;
	String EmailA;
	
private static final long serialVersionUID = 1059232686459895282L;

	boolean admin=false;
	boolean noadmin=false;
	
	static Scanner in = new Scanner(System.in);

    public List<User> users;
    

    
    public static UserManager getUserManager() {
    	if (instance==null) {
    		FileInputStream fis = null;
    		ObjectInputStream in = null;
    		
    		File file = new File("saveUsers.ser");
    		
    		try {
    			fis = new FileInputStream(file);
    			in = new ObjectInputStream(fis);
    			instance = (UserManager) in.readObject();

    			fis.close();
    			in.close();
    			
    		} catch (IOException e) {
    			instance=new UserManager();
        		instance.users = new ArrayList<User>();
        		instance.initializeDefaultUsers();
        		return instance;
    		} catch (ClassNotFoundException e) {
    			
    			e.printStackTrace();
    		}
    		
    	
    	}
    	return instance;
    }
    
	public static void save() {
		LoadController.save(instance, "medialab/saveUsers.ser");
	}
	

    private void initializeDefaultUsers() {
        // Δημιουργία και προσθήκη default χρηστών
        User defaultUser1 = new User("user1", "pass1", "John", "Doe", "ID1", "user1@mail.com");
        User defaultUser2 = new User("user2", "pass2", "Jane", "Smith", "ID2", "user2@mail.com");
        User admin = new User("medialab", "medialab_2024", "Polina", "Georgiou", "el19088", "el19088@ntua.gr");

        addUser(defaultUser1);
        addUser(defaultUser2);
        addUser(admin);
    }

    public List<User> getUsers() {
        return users;
    }

    public void addUser(User user) {
        users.add(user);
    }

    public void removeUser(User user) {
        Iterator<User> iterator = users.iterator();
        while (iterator.hasNext()) {
            User currentUser = iterator.next();
            if (currentUser.getID().equals(user.getID())) {
                iterator.remove();
                break;
            }
        }
    }
    
    
    
    
      public void registerUser() {

        User newUser = new User(UsernameA, PasswardA, FirstNameA, LastNameA, IDA, EmailA);
        
        
        addUser(newUser);
        listUsers();

        System.out.println("Registration successful.");

        
        
    } 
      
      
      public User login(String username, String password) {
          for (User currentUser : users) {
              if (currentUser.getUsername().equals(username) && currentUser.getPassword().equals(password)) {
                  return currentUser;
              }
          }
          return null;
      }
      
      
      
      
      public void loginn() {
//          enterUsername = Username.getText();
//          enterPassward = Passward.getText();

          User loggedInUser = login(enterUsername, enterPassward);

          if (loggedInUser != null) {
              System.out.println("Login successful.");

              if (loggedInUser.getUsername().equals("medialab") && loggedInUser.getPassword().equals("medialab_2024")) {
                  System.out.println("Logged in as administrator.");
                  admin = true;
              } else {
                  System.out.println("Logged in as regular user.");
                  noadmin = true;
                 // switchToScene3();
                 
              }
          } else {
              System.out.println("Login failed. Incorrect username or password.");
              //switchToScene1();
          }
      }
      

      
      @FXML
      private void login1(ActionEvent event) {
          
          loginn();
      }

   
   
 
    
    private void listUsers() {
        List<User> users = getUsers();
        if (users.isEmpty()) {
            System.out.println("No users available.");
        } else {
            System.out.println("List of users:");
            for (User user : users) {
                System.out.println(user.getID());
            }
        }
    }
    
    
    @Override
    public String toString() {
        StringBuilder total = new StringBuilder("\n");
        for (User user : users) {
            total.append(user.toString());
        }
        return total.toString();
    }
}