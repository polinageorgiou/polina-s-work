package application;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import application.Book.CommentAndRating;

import java.io.Serializable;


/**
 * Represents a book in the library.
 */
public class Book  implements Serializable{
	
	private List<CommentAndRating> commentsAndRatings;
	
	private String title, author, publisher, category;
	private int isbn, yop, noc; //yop=year of publishing, noc=number of copies
	
	
	
	/**
     * Constructs a new Book object with default values.
     */
	public Book() {
		title=null;
		author=null;
		publisher=null;
		category=null;
		isbn=0;
		yop=0;
		noc=0;		
}
	
	
	
	/**
     * Constructs a new Book object with specified values.
     * 
     * @param title     the title of the book
     * @param author    the author of the book
     * @param publisher the publisher of the book
     * @param category  the category of the book
     * @param isbn      the ISBN of the book
     * @param yop       the year of publishing of the book
     * @param noc       the number of copies of the book
     */
	public Book(String title, String author, String publisher, String category, int isbn, int yop, int noc) {
		this.title=title;
		this.author=author;
		this.publisher=publisher;
		this.category=category;
		this.isbn=isbn;
		this.yop=yop;
		this.noc=noc;
		this.commentsAndRatings = new ArrayList<>();
	}
	
	
	
	/**
     * Returns the list of comments and ratings for this book.
     * 
     * @return the list of comments and ratings
     */
	public List<CommentAndRating> getCommentsAndRatings() {
        return commentsAndRatings;
    }

	
	
	 /**
     * Adds a comment and rating for this book.
     * 
     * @param user    the user who made the comment and rating
     * @param comment the comment
     * @param rating  the rating
     */
    public void addCommentAndRating(User user, String comment, int rating) {
        CommentAndRating commentAndRating = new CommentAndRating(user.getUsername(), comment, rating);
        commentsAndRatings.add(commentAndRating);
    }
    
    
    
    /**
     * Represents a comment and rating for a book.
     */
        public static class CommentAndRating implements Serializable {
        private String user;
        private String comment;
        private int rating;

        
        
        /**
         * Constructs a new CommentAndRating object with specified values.
         * 
         * @param user    the user who made the comment and rating
         * @param comment the comment
         * @param rating  the rating
         */
        
        public CommentAndRating(String user, String comment, int rating) {
            this.user = user;
            this.comment = comment;
            this.rating = rating;
        }
        
        
        /**
         * Returns the comment.
         * 
         * @return the comment
         */
        public String getComment() {
            return comment;
        }

        /**
         * Returns the rating.
         * 
         * @return the rating
         */
        public int getRating() {
            return rating;
        }

        /**
         * Returns the user who made the comment and rating.
         * 
         * @return the user
         */
		public String getUser() {
			return user;
		}

        
    }
    
   
    
    
        /**
         * Returns the title of the book.
         * 
         * @return the title of the book
         */
	public String getTitle() {
        return title;
    }
	
	/**
     * Returns the ISBN of the book.
     * 
     * @return the ISBN of the book
     */
	public int getIsbn() {
        return isbn;
    }
	/**
     * Returns the number of copies of the book.
     * 
     * @return the number of copies of the book
     */
	public int getNumberOfCopies() {
        return noc;
    }
	
	 /**
     * Returns the year of publishing of the book.
     * 
     * @return the year of publishing of the book
     */
	public int getYearOfPublishing() {
        return yop;
    }
	
	/**
     * Returns the author of the book.
     * 
     * @return the author of the book
     */
	public String getAuthor() {
        return author;
    }
	
	 /**
     * Returns the category of the book.
     * 
     * @return the category of the book
     */
	public String getCategory() {
        return category;
    }
	
	/**
     * Sets the title of the book.
     * 
     * @param title the title of the book
     */
	public void setTitle(String title) {
        this.title = title;
    }
	
	
	 /**
     * Sets the author of the book.
     * 
     * @param author the author of the book
     */
    public void setAuthor(String author) {
        this.author = author;
    }

    /**
     * Sets the publisher of the book.
     * 
     * @param publisher the publisher of the book
     */
    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    /**
     * Sets the category of the book.
     * 
     * @param category the category of the book
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * Sets the ISBN of the book.
     * 
     * @param isbn the ISBN of the book
     */
    public void setIsbn(int isbn) {
        this.isbn = isbn;
    }

    /**
     * Sets the year of publishing of the book.
     * 
     * @param yop the year of publishing of the book
     */
    public void setYearOfPublishing(int yop) {
        this.yop = yop;
    }

    /**
     * Sets the number of copies of the book.
     * 
     * @param noc the number of copies of the book
     */
    public void setNumberOfCopies(int noc) {
        this.noc = noc;
    }
    
    
	
    /**
     * Returns a string representation of the book.
     * 
     * @return a string representation of the book
     */
	@Override
	public String toString() {
		int sum = 0;
		for(CommentAndRating rating : commentsAndRatings) {
			sum += rating.getRating();
		}
		double rating = commentsAndRatings.isEmpty() ? 0 : (double) sum/commentsAndRatings.size();
		
		return "\nTitle: " + title + "\nAuthor: " + author + "\nPublisher: " + publisher + "\nCategory: " + category +
				"\nISBN: " + isbn + "\nYear of Publishing: " + yop + "\nNumber of Copies: " + noc + "\n" + "Average rating: " + rating + "\n" + "Number of ratings: " + commentsAndRatings.size();
	}
	
	
	 /**
     * Indicates whether some other object is "equal to" this one.
     * 
     * @param obj the reference object with which to compare
     * @return {@code true} if this object is the same as the obj argument; {@code false} otherwise
     */
    @Override
	public boolean equals(Object obj) {
	    if (this == obj) {
	        return true;
	    }
	    if (obj == null || getClass() != obj.getClass()) {
	        return false;
	    }
	    Book other = (Book) obj;
	    return isbn == other.isbn;
	}
	
}