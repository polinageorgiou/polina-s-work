package application;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoadController {
	
	
	static String fileName = null;
	static Library lib = new Library();
	static CategoryManager categoryManager = new CategoryManager();
	static UserManager user = new UserManager();
	static LoanManager loan = new LoanManager();
	static Boolean running = true;
	
	
	@FXML
    private TextArea outputTextArea;
    @FXML
    private TextField Filename;
    @FXML
    private TextField Filenamesave;
    
    
    
    /**
     * Κανει load ολες τις βασεις.
     */
 public static void loadScript() {
	Library.getLibrary();
	CategoryManager.getCategoryManager();
	UserManager.getUserManager();
	LoanManager.getLoanManager();
}
    
    /**
     * γηθεθιγε.
     * 
     * @param object το αντικ
     * @param fileName το ονομα
     * @return νγενινιθδγρ
     */
    public static void save(Object object, String fileName) {	

	    FileOutputStream fos = null;
	    ObjectOutputStream out = null;

	    try { 
	        fos = new FileOutputStream(fileName);
	        out = new ObjectOutputStream(fos);
	        out.writeObject(object);
	    } catch (FileNotFoundException e) {
	        e.printStackTrace();
	    } catch (IOException e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if (fos != null) {
	            	fos.flush();
	                fos.close();
	            }
	            if (out != null) {
	                out.close();
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        	        
	    }

	    
	}
    
 

}
