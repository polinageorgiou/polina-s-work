package application;

import java.io.IOException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class ShowLoansforUserController {
	
	
	 @FXML
	    private TextArea outputTextArea;
	 
	    
	    
	    private void showMessage(String message) {
	        outputTextArea.appendText(message + "\n");
	    }
	

	
	 public void listLoans() {
		    List<Loan> loans = LoanManager.getLoanManager().getLoans();
		    if (loans.isEmpty()) {
		    	showMessage("No loans available.");
		    } else {
		    	showMessage("List of loans:");
		        for (Loan currentloan : loans) {		        	
		        	User currentUser = currentloan.getUser();
		        	String userName = currentUser.getUsername();
		        	String password = currentUser.getPassword();
		        	if (userName.equals(Scene1Controller.enterUsername) && password.equals(Scene1Controller.enterPassward)) {
		        	//showMessage("User:" + userName);
		        	//showMessage(currentloan.getUser());
		        	Book currentBook = currentloan.getBook();
		        	String bookName = currentBook.getTitle();
		        	showMessage("Book:" + bookName);
		        	checkLoanDueDate(currentloan);
		        	}
		        }
		    }
		}
	 
	 
	 public void checkLoanDueDate(Loan loan) {
		 
	        LocalDate currentDate = LocalDate.now();
	        LocalDate dueDate = loan.getDueDate(); // Προσθέτουμε 5 ημέρες στην ημερομηνία έναρξης

	        long overdueDays = ChronoUnit.DAYS.between(dueDate, currentDate);
	        long remainingDays = ChronoUnit.DAYS.between(currentDate, dueDate);

	        if (overdueDays > 0) {
	        	showMessage("This loan is overdue by " + overdueDays + " days.");
	           
	        }
	        else {
	        	showMessage("This loan is not overdue");
	        	showMessage("You have to return the book in " + remainingDays + " days");
	        }
	    }
	 
	 
	 @FXML
	    private void switchToScene3(ActionEvent event) throws IOException {
	        Parent root = FXMLLoader.load(getClass().getResource("Scene3.fxml"));
	        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
	        Scene scene = new Scene(root);
	        stage.setScene(scene);
	        stage.show();
	    	
	    }

}
