package application;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class ReturnController {
	
	@FXML
    private TextField ID;
    @FXML
    private TextField ISBN;
    @FXML
    private TextField Comment;
    @FXML
    private TextField Rating;
    @FXML
    private TextArea outputTextArea;
    
    private List<Loan> loans;
    
    
    public ReturnController() {
      
      loans = LoanManager.getLoanManager().getLoans();
  }

    
    private void showMessage(String message) {
        outputTextArea.appendText(message + "\n");
    }
    
    
    
    
   
    
    
    public void returnBookandAddCommentRating() {
        String userId = ID.getText();
        User user = findUserByID(userId);
        
        int bookIsbn = Integer.parseInt(ISBN.getText());
        Book book = findBookByISBN(bookIsbn);

        if (user != null && book != null) {
        	       	 
            Loan loanToReturn = findLoan(user, book);
            if (loanToReturn != null) {
                terminateLoan(loanToReturn);
                book.setNumberOfCopies(book.getNumberOfCopies() + 1);
	            user.setNumberOfBooksBorrowed(user.getNumberOfBooksBorrowed() - 1);
                String comment = Comment.getText();
                int rating = Integer.parseInt(Rating.getText());
                book.addCommentAndRating(user, comment, rating);
                showMessage("Book returned successfully.");
            } else {
                showMessage("Loan not found.");
            }
        } else {
            showMessage("User or book not found.");
        }
        
    }
    
   
    public void terminateLoan(Loan loan) {
    	LoanManager.getLoanManager().removeLoan(loan);
        checkLoanDueDate(loan);
        showMessage("Loan terminated successfully.");
    }
    
   
    
    public void checkLoanDueDate(Loan loan) {
        LocalDate currentDate = LocalDate.now();
        LocalDate dueDate = loan.getDueDate(); // Προσθέτουμε 5 ημέρες στην ημερομηνία έναρξης

        long overdueDays = ChronoUnit.DAYS.between(dueDate, currentDate);

        if (overdueDays > 0) {
            // Ο δανεισμός είναι καθυστερημένος, μπορείτε να προσθέσετε τις απαραίτητες ενέργειες
            System.out.println("This loan is overdue by " + overdueDays + " days.");
            // Προσθέστε εδώ τυχόν άλλες ενέργειες που θέλετε να εκτελέσετε όταν ο δανεισμός είναι καθυστερημένος
        }
        else {
        	showMessage("This loan is not overdue");
        }
    }
    
    

    public Loan findLoan(User user, Book book) {
        for (Loan loan : loans) {
            if (loan.getUser().equals(user) && loan.getBook().equals(book)) {
                return loan;
            }
        }
        return null;
    } 
    

	
    @FXML
    private void switchToScene3(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Scene3.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    	
    }
	 
	 
	 private static Book findBookByISBN(int isbn) {
		    for (Book book : Library.getLibrary().getBooks()) {
		        if (book.getIsbn() == isbn) {
		            return book;
		        }
		    }
		    return null; // Επιστρέφει null αν το βιβλίο δεν βρεθεί
		}
	 
	 
	 private static User findUserByID(String id) {
	        for (User user :  UserManager.getUserManager().getUsers()) {
	            if (user.getID().equals(id)) {
	                return user;
	            }
	        }
	        return null;
	    }
	 
	 
	


}
