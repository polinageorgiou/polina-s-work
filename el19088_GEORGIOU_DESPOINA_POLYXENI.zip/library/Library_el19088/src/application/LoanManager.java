package application;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;


public class LoanManager implements Serializable {
	
//	@FXML
//    private TextArea outputTextArea;
 
    
    
	private static LoanManager instance;
    private List<Loan> loans;

    public static LoanManager getLoanManager() {
    	if (instance==null) {
    		FileInputStream fis = null;
	ObjectInputStream in = null;
    		File file = new File("saveLoans.ser");
    		
    		try {
    			fis = new FileInputStream(file);
    			in = new ObjectInputStream(fis);
    			instance = (LoanManager) in.readObject();

    			fis.close();
    			in.close();
    			
    		} catch (IOException e) {
    			instance=new LoanManager();
        		instance.loans = new ArrayList<>();    		
        		return instance;
    		} catch (ClassNotFoundException e) {
    			
    			e.printStackTrace();
    		}
    		
    	
    		
    	}
    	return instance;
    }
    
	public static void save() {	
		LoadController.save(instance, "medialab/saveLoans.ser");
	}
	
	


    public  List<Loan> getLoans() {
        return loans;
    }

    public void addLoan(Loan loan) {
        loans.add(loan);
    }

    public void removeLoan(Loan loan) {
        Iterator<Loan> iterator = loans.iterator();
        while (iterator.hasNext()) {
            Loan currentLoan = iterator.next();
            if (currentLoan.equals(loan)) {
                iterator.remove();
                //increaseAvailableCopies(loan.getBook());
                //decreaseNumberOfBooksBorrowed(loan.getUser());
                break;
            }
        }
    }
    
    
    public void removeLoansForBook(Book book) {
        Iterator<Loan> iterator = loans.iterator();
        while (iterator.hasNext()) {
            Loan loan = iterator.next();
            if (loan.getBook().equals(book)) {
                iterator.remove();
            }
        }
    }
    
    public void updateLoansAndCopiesForDeletedUser(User deletedUser) {
        Iterator<Loan> iterator = loans.iterator();
        while (iterator.hasNext()) {
            Loan loan = iterator.next();
            if (loan.getUser().equals(deletedUser)) {
                iterator.remove();

                Book book = loan.getBook();
                book.setNumberOfCopies(book.getNumberOfCopies() + 1);
            }
        }
    }
    
   
    public void updateLoansForDeletedCategory(String deletedCategory) {
        Iterator<Loan> iterator = loans.iterator();
        while (iterator.hasNext()) {
            Loan loan = iterator.next();
            Book book = loan.getBook();
            if (book.getCategory().equals(deletedCategory)) {
                // Διαγραφή του δανείου
                iterator.remove();
                loan.getUser().setNumberOfBooksBorrowed(loan.getUser().getNumberOfBooksBorrowed() - 1);
            }
        }
    }
    

//    private void increaseAvailableCopies(Book book) {
//        book.setNumberOfCopies(book.getNumberOfCopies() + 1);
//    }
//
//    
//    private void decreaseNumberOfBooksBorrowed(User user) {
//    	user.setNumberOfBooksBorrowed(user.getNumberOfBooksBorrowed() - 1);
//    }
    
    
    
    public void checkLoanDueDate(Loan loan) {
        LocalDate currentDate = LocalDate.now();
        LocalDate dueDate = loan.getDueDate(); // Προσθέτουμε 5 ημέρες στην ημερομηνία έναρξης

        long overdueDays = ChronoUnit.DAYS.between(dueDate, currentDate);

        if (overdueDays > 0) {
            // Ο δανεισμός είναι καθυστερημένος, μπορείτε να προσθέσετε τις απαραίτητες ενέργειες
            System.out.println("This loan is overdue by " + overdueDays + " days.");
            // Προσθέστε εδώ τυχόν άλλες ενέργειες που θέλετε να εκτελέσετε όταν ο δανεισμός είναι καθυστερημένος
        }
        else {
        	System.out.println("This loan is not overdue");
        }
    }
    
    public void displayOpenLoans() {
        System.out.println("Open Loans:");
        for (Loan loan : loans) {
            System.out.println(loan);
        }
    }

    public void terminateLoan(Loan loan) {
        removeLoan(loan);
        checkLoanDueDate(loan);
    }

//    public void loanBook(Book book, User user) {
//        if (book.getNumberOfCopies() > 0 && user.canBorrowMoreBooks()) {
//            Loan loan = new Loan(book, user);
//            addLoan(loan);
//        } 
//    }
    
    public void loanBook(Book book, User user) {
        if (book.getNumberOfCopies() > 0 && user.canBorrowMoreBooks()) {
            Loan loan = new Loan(book, user);
            addLoan(loan);
        } 
    }
    
    
    public Loan findLoan(User user, Book book) {
        for (Loan loan : loans) {
            if (loan.getUser().equals(user) && loan.getBook().equals(book)) {
                return loan;
            }
        }
        return null;
    }
    

    
}

