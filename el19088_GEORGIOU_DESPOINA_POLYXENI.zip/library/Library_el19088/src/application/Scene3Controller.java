package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.fxml.Initializable;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.fxml.FXMLLoader;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class Scene3Controller implements Initializable {

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}
	
	@FXML
	private void switchToSceneSearch(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Search.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    	
    }
	
	 
	@FXML
	private void switchToSceneBorrow(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Borrow.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    	
    }

	@FXML
	private void switchToSceneReturn(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Return.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    	
    }
	
	
	@FXML
	private void switchToSceneShowLoansforUser(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("ShowLoansforUser.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    	
    }
	
	
	
	 @FXML
	    private void switchToScene1(ActionEvent event) {
	  	  
	  	        
	  	        ((Stage)((Node) event.getSource()).getScene().getWindow()).close();
	  	        
	  	    
	  	}
	 
	 


}
