package application;

import java.io.IOException;
import java.util.List;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class CategoryOperationsController {
	
	
	@FXML
    private TextField Title;
	@FXML
    private TextField OldTitle;
    @FXML
    private TextArea outputTextArea;
    
    private void showMessage(String message) {
        outputTextArea.appendText(message + "\n");
    }
	
	
	 public void addCategory() {
	        String title =Title.getText();
	        Category newCategory = new Category(title);
	        CategoryManager.getCategoryManager().addCategory(newCategory);
	        showMessage("Category added successfully!");
	    }
	 
	 
	 public void updateCategory() {    	    
	    	    String oldTitle =OldTitle.getText();
	    	    Category categoryToUpdate = findCategoryByTitle(oldTitle);
	    	    if (categoryToUpdate != null) {	    	        
	    	        String newTitle = Title.getText();
	    	        CategoryManager.getCategoryManager().updateCategory(categoryToUpdate, newTitle);
	    	        showMessage("Category updated successfully!");
	    	    } else {
	    	    	showMessage("Category not found.");
	    	    }
	    }
	 
	 private static Category findCategoryByTitle(String title) {
	        List<Category> categories = CategoryManager.getCategoryManager().getCategories();
	        for (Category category : categories) {
	            if (category.getTitle().equalsIgnoreCase(title)) {
	                return category;
	            }
	        }
	        return null;
	    }
	 
	 public void deleteCategory() {	       
	        String titleToDelete = Title.getText();
	        Category categoryToDelete = findCategoryByTitle(titleToDelete);
	        
	        if (categoryToDelete != null) {
	            String categoryName = categoryToDelete.getTitle();
	            CategoryManager.getCategoryManager().removeCategory(categoryToDelete);
	            LoanManager.getLoanManager().updateLoansForDeletedCategory(categoryName);
	            Library.getLibrary().deleteBookforCategory(categoryName);
	            showMessage("Category deleted successfully!");

	        } else {
	        	showMessage("Category not found.");
	        }
	    }
	 
	 
	 public void listCategories() {
	        List<Category> categories = CategoryManager.getCategoryManager().getCategories();
	        if (categories.isEmpty()) {
	        	showMessage("No categories available.");
	        } else {
	        	showMessage("List of categories:");
	            for (Category category : categories) {
	            	showMessage(category.getTitle());
	            }
	        }
	    }
	 
	 @FXML
	    private void switchToScene4(ActionEvent event) throws IOException {
	        Parent root = FXMLLoader.load(getClass().getResource("Scene4.fxml"));
	        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
	        Scene scene = new Scene(root);
	        stage.setScene(scene);
	        stage.show();
	    	
	    }

}
