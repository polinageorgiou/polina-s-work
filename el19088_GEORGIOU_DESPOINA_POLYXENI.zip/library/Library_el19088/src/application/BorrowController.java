package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class BorrowController {
	
	@FXML
    private TextField ID;
    @FXML
    private TextField ISBN;
    @FXML
    private TextArea outputTextArea;

    
    private void showMessage(String message) {
        outputTextArea.appendText(message + "\n");
    }
    
	
	 public void borrow(){
		
	        String userId = ID.getText();
	        User user = findUserByID(userId);
	        
	        int bookIsbn = Integer.parseInt(ISBN.getText());
	        Book book = findBookByISBN(bookIsbn);
	        
	        String userName = user.getUsername();
        	String password = user.getPassword();
        	if (userName.equals(Scene1Controller.enterUsername) && password.equals(Scene1Controller.enterPassward)) {

	        if (user != null && book != null) {
	        	loanBook(book, user);
	        } else {
	        	showMessage("User or book not found.");

	        }	
        	}
        	else {
        		showMessage("You are trying to borrow a book as another user");
        		
        	}
	}
	 
	 public void loanBook(Book book, User user) {
	        if (book.getNumberOfCopies() > 0 && user.canBorrowMoreBooks()) {
	            Loan loan = new Loan(book, user);
	            LoanManager.getLoanManager().addLoan(loan);
	            book.setNumberOfCopies(book.getNumberOfCopies() - 1);
	            user.setNumberOfBooksBorrowed(user.getNumberOfBooksBorrowed() + 1);
	            showMessage("Book loaned successfully.");
	        } else {
	        	showMessage("No available copies of the book or user cannot rent more books.");
	        }
	    }
	 
	 
	 @FXML
	    private void switchToScene3(ActionEvent event) throws IOException {
	        Parent root = FXMLLoader.load(getClass().getResource("Scene3.fxml"));
	        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
	        Scene scene = new Scene(root);
	        stage.setScene(scene);
	        stage.show();
	    	
	    }
	 
	 
	 
	 private static Book findBookByISBN(int isbn) {
		    for (Book book : Library.getLibrary().getBooks()) {
		        if (book.getIsbn() == isbn) {
		            return book;
		        }
		    }
		    return null; // Επιστρέφει null αν το βιβλίο δεν βρεθεί
		}
	 
	 
	 private static User findUserByID(String id) {
	        for (User user :  UserManager.getUserManager().getUsers()) {
	            if (user.getID().equals(id)) {
	                return user;
	            }
	        }
	        return null;
	    }

}
