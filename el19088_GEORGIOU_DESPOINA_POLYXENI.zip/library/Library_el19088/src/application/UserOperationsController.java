package application;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class UserOperationsController {
	
	
	@FXML
    private TextField Username;
	@FXML
    private TextField Password;
    @FXML
    private TextField Firstname;
    @FXML
    private TextField Lastname;
    @FXML
    private TextField ID;
    @FXML
    private TextField Email;
    @FXML
    private TextField IDToUpdate;
    @FXML
    private TextArea outputTextArea;
    
    
    private void showMessage(String message) {
        outputTextArea.appendText(message + "\n");
    }
	
public void addUser() {
	
		
		String username, password, firstname, lastname, id, mail;
		
		username = Username.getText();
		
		password = Password.getText();
		
		firstname = Firstname.getText();

		lastname = Lastname.getText();
		
		id = ID.getText();
	
		mail = Email.getText();
		
		User u = new User(username, password, firstname, lastname, id, mail);
		UserManager.getUserManager().addUser(u);
		showMessage("\nUser  added " );
	}


public void updateUser() {   
    String idToUpdate = IDToUpdate.getText();
	
    User userToUpdate = findUserByID(idToUpdate);

    if (userToUpdate != null) {
       
        updateUserDetails(userToUpdate);
        showMessage("User details updated successfully.");
    } else {
    	showMessage("User not found.");
    }
}


private static User findUserByID(String id) {
    for (User user : UserManager.getUserManager().getUsers()) {
        if (user.getID().equals(id)) {
            return user;
        }
    }
    return null;
}

private void updateUserDetails(User user) {
	

    String newUsername = Username.getText();
    user.setUsername(newUsername);

    String newPassward = Password.getText();
    user.setUsername(newPassward);

    String newName = Firstname.getText();
    user.setName(newName);

    String newLastname = Lastname.getText();
    user.setLastname(newLastname);

    String newID = ID.getText();
    user.setID(newID);

    String newMail = Email.getText();
    user.setMail(newMail);
    

}


 public void deleteUser() {
    String idToDelete = ID.getText();

    User userToDelete = null;
    for (User user : UserManager.getUserManager().getUsers()) {
        if (user.getID().equals(idToDelete)) {
            userToDelete = user;
            break;
        }
    }

    if (userToDelete != null) {
    	UserManager.getUserManager().removeUser(userToDelete);
    	LoanManager.getLoanManager().updateLoansAndCopiesForDeletedUser(userToDelete);
    	showMessage("User deleted successfully.");
    } else {
    	showMessage("User not found.");
    }
}
 
 public void listUsers() {
     List<User> users = UserManager.getUserManager().getUsers();
     if (users.isEmpty()) {
    	 showMessage("No users available.");
     } else {
    	 showMessage("List of users:");
         for (User user : users) {
        	 showMessage(user.getID());
         }
     }
 }



@FXML
private void switchToScene4(ActionEvent event) throws IOException {
    Parent root = FXMLLoader.load(getClass().getResource("Scene4.fxml"));
    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    Scene scene = new Scene(root);
    stage.setScene(scene);
    stage.show();
	
}

}
