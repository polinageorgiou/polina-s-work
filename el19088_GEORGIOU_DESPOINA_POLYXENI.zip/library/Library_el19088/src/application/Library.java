package application;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Library implements Serializable{
	
	private static Library instance;
	
	private List<Book> collection;
	
	
	
	public static Library getLibrary() {  
    	if (instance==null) {
    		FileInputStream fis = null;
    		ObjectInputStream in = null;
    		
    		File file = new File("saveLibrary.ser");
    		
    		try {
    			fis = new FileInputStream(file);
    			in = new ObjectInputStream(fis);
    			instance = (Library) in.readObject();

    			fis.close();
    			in.close();
    			
    		} catch (IOException e) {
    			instance=new Library();
        		instance.collection = new ArrayList<Book>();
        		instance.initializeDefaultBooks();
        		return instance;
    		} catch (ClassNotFoundException e) {
    			
    			e.printStackTrace();
    		}
    		
    	
    		
    	}
    	return instance;
    }
	
	public static void save() {	
		LoadController.save(instance, "medialab/saveLibrary.ser");
	}
	
	
	
	private void initializeDefaultBooks() {
       
        Book book1 = new Book("1","1","1","1",1,1,1);
        Book book2 = new Book("2","2","2","2",2,2,2);
         
        addBook(book1);
        addBook(book2);
        
    }
	
	public List<Book> getBooks() {
        return collection;
	}
	
	public void addBook(Book book) {
		collection.add(book);
	}
	
	
	public void removeBook(Book book) {
        Iterator<Book> iterator = collection.iterator();
        while (iterator.hasNext()) {
            Book currentBook = iterator.next();
            if (currentBook.getIsbn() == book.getIsbn()) {
                iterator.remove();
                break;
            }
        }
	}
	
	
	public void updateBookDetails(int isbn, String newTitle, String newAuthor, String newPublisher,
            String newCategory, int newYear, int newCopies) {
for (Book book : collection) {
if (book.getIsbn() == isbn) {
// Βρέθηκε το βιβλίο με το συγκεκριμένο ISBN, εκτελούμε τη μετατροπή.
book.setTitle(newTitle);
book.setAuthor(newAuthor);
book.setPublisher(newPublisher);
book.setCategory(newCategory);
book.setYearOfPublishing(newYear);
book.setNumberOfCopies(newCopies);
break;
		}
	}
}
	
	
	public void deleteBookforCategory(String categoryName)	{
		Iterator<Book> iterator = getBooks().iterator();
		while (iterator.hasNext()) {
			Book book = iterator.next();
			if (book.getCategory().equals(categoryName)) {
            iterator.remove();
			}
		}
	}
	
	public List<Book> searchBook(String title, String author, int year) {
	    List<Book> result = new ArrayList<>();

	    for (Book book : collection) {
	        boolean match = false;

	        if (title != null && !title.isEmpty() && book.getTitle().contains(title)) {
	            match = true;
	        }

	        if (author != null && !author.isEmpty() && book.getAuthor().contains(author)) {
	            match = true;
	        }

	        if (year > 0 && book.getYearOfPublishing() == year) {
	            match = true;
	        }

	        if (match) {
	            result.add(book);
	        }
	    }

	    return result;
	}

	
	
            
            
	@Override
	public String toString() {
		String total = "\n";
		
		Iterator<Book> i = collection.iterator();
		while(i.hasNext()) {
			Book b = (Book) i.next();
			total = total + b.toString();
		}
		
		return total;
	}
}